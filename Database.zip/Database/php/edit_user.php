<?php
session_start();
include('connect.php');

// Check if user is logged in and is an admin
if (!isset($_SESSION['email']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Check if the ID is provided
if (!isset($_GET['id'])) {
    echo "User ID is missing.";
    exit();
}

$userId = $_GET['id'];

// Fetch user details
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    echo "User not found.";
    exit();
}

// Update user details if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
    $email = $_POST['email'];
    $role = $_POST['role'];

    $updateSql = "UPDATE users SET email = ?, role = ? WHERE id = ?";
    $updateStmt = $conn->prepare($updateSql);
    $updateStmt->bind_param("ssi", $email, $role, $userId);

    if ($updateStmt->execute()) {
        echo "User updated successfully!";
        header("Location: dashboard.php"); // Redirect back to dashboard
        exit();
    } else {
        echo "Error updating user.";
    }
}

// Delete user if delete form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete'])) {
    $deleteSql = "DELETE FROM users WHERE id = ?";
    $deleteStmt = $conn->prepare($deleteSql);
    $deleteStmt->bind_param("i", $userId);

    if ($deleteStmt->execute()) {
        echo "User deleted successfully!";
        header("Location: dashboard.php"); // Redirect back to dashboard
        exit();
    } else {
        echo "Error deleting user.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit User</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <form method="POST">
        <label>Email:</label>
        <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
        <label>Role:</label>
        <select name="role" required>
            <option value="admin" <?php if ($user['role'] == 'admin') echo 'selected'; ?>>Admin</option>
            <option value="user" <?php if ($user['role'] == 'user') echo 'selected'; ?>>User</option>
        </select>
        <button type="submit" name="update">Save Changes</button>
        <button type="submit" name="delete" onclick="return confirm('Are you sure you want to delete this user?')">Delete User</button>
        <a href="dashboard.php">Back to Dashboard</a>
    </form>
</body>
</html>
