<?php
session_start();
include('connect.php');

// Check if user is logged in and is an admin
if (!isset($_SESSION['email']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php"); // Redirect to login if not an admin
    exit();
}

// Fetch the list of users
$sql = "SELECT * FROM users";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../css/dashboard.css"> 
</head>

<body>
    <div class="container">
        <h1>Welcome to the Admin Dashboard</h1>
        <h2>User List</h2>
        <table>    
    <thead>
        <tr>
            <th>User ID</th>
            <th>Email</th>
            <th>Actions</th> <!-- New column for actions -->
        </tr>
    </thead>
    <tbody>
        <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?php echo htmlspecialchars($row['id']); ?></td>
                <td><?php echo htmlspecialchars($row['email']); ?></td>
                <td>
                    <a href="edit_user.php?id=<?php echo $row['id']; ?>">Edit</a> <!-- Edit link -->
                </td>
            </tr>
        <?php } ?>
    </tbody>
</table>

        <div class="logout">
            <a href="logout.php">Logout</a>
        </div>
    </div>
</body>

</html>

<?php
$conn->close();
?>
