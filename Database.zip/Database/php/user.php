<?php
session_start();
include('connect.php'); // Database connection file

// Check if user is logged in
if (!isset($_SESSION['email'])) {
    header("Location: login.php"); // Redirect to login page if not logged in
    exit();
}

// Fetch user details from the database
$email = $_SESSION['email'];
$sql = "SELECT email, created_at FROM users WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    echo "User not found.";
    exit();
}

// Format the "member since" date
$created_at = date("F j, Y", strtotime($user['created_at']));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="../css/user.css">
</head>
<body>
    <!-- Navbar -->
    <div class="navbar">
        <a href="user_dashboard.php">Dashboard</a>
        <a href="profile.php">Profile</a>
        <a href="logout.php" class="logout">Logout</a>
    </div>

    <!-- User Info Section -->
    <div class="container">
        <h1>Welcome to your Dashboard!</h1>
        
        <div class="user-info">
            <h2>User Information</h2>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
            <p><strong>Member since:</strong> <?php echo htmlspecialchars($created_at); ?></p>
        </div>
    </div>
</body>
</html>

<?php
$conn->close(); // Close the database connection
?>
