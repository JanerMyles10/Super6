<?php
session_start();
include('connect.php');

// Check if user is logged in
if (!isset($_SESSION['email'])) {
    header("Location: login.php"); // Redirect to login if not logged in
    exit();
}

// Fetch user details
$email = $_SESSION['email'];
$sql = "SELECT id, email FROM users WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    echo "User not found.";
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="../css/user_dashboard.css"> 
</head>
<body>
    <div class="container">
        <h1>Welcome to your Dashboard!</h1>
        
        <h2>Your Details</h2>
        <table>
            <tr>
                <th>User ID:</th>
                <td><?php echo htmlspecialchars($user['id']); ?></td>
            </tr>
            <tr>
                <th>Email:</th>
                <td><?php echo htmlspecialchars($user['email']); ?></td>
            </tr>
        </table>

        <div class="actions">
            <a href="user.html">Update Profile</a> <!-- Link to update profile page -->
            <a href="logout.php" class="logout">Logout</a> <!-- Link to logout -->
        </div>
    </div>
</body>
</html>

<?php
$conn->close();
?>
