<?php
include 'db-connect.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM users WHERE id = $id";
    $result = $conn->query($sql);
    $data = $result->fetch_assoc();
}

if (isset($_POST['update'])) {
    $email = $_POST['email'];

    $update_sql = "UPDATE users SET email = '$email' WHERE id = $id";
    $conn->query($update_sql);

    header("Location: index.php");
}
?>
<form method="post">
    <label>Email: <input type="email" name="email" value="<?php echo $data['email']; ?>"></label><br>
    <button type="submit" name="update">Update</button>
</form