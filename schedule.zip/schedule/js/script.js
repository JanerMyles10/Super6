var calendar;
var Calendar = FullCalendar.Calendar;
var events = [];
$(function() {
    if (!!scheds) {
        Object.keys(scheds).map(k => {
            var row = scheds[k]
            events.push({ id: row.id, title: row.title, start: row.start_datetime, end: row.end_datetime });
        })
    }
    var date = new Date()
    var d = date.getDate(),
        m = date.getMonth(),
        y = date.getFullYear()

    calendar = new Calendar(document.getElementById('calendar'), {
        headerToolbar: {
            left: 'prev,next today',
            right: 'dayGridMonth,dayGridWeek,list',
            center: 'title',
        },
        selectable: true,
        themeSystem: 'bootstrap',
        events: events,
        eventClick: function(info) {
            var _details = $('#event-details-modal')
            var id = info.event.id
            if (!!scheds[id]) {
                _details.find('#title').text(scheds[id].title)
                _details.find('#description').text(scheds[id].description)
                _details.find('#start').text(scheds[id].sdate)
                _details.find('#end').text(scheds[id].edate)
                _details.find('#edit,#delete').attr('data-id', id)
                _details.modal('show')
            } else {
                alert("Event is undefined");
            }
        },
        editable: true
    });
    // Assuming the `scheds` variable contains the schedule data
    $(document).ready(function() {
        $('#calendar').fullCalendar({
            events: scheds,  // Make sure `scheds` is populated with the correct event data
            eventClick: function(event, jsEvent, view) {
                alert('Event clicked: ' + event.title);  // You can customize this to open a modal or redirect
            }
        });
    });
    

    calendar.render();

    // Periodic check for upcoming events
    setInterval(checkUpcomingEvents, 60000); // Check every 60 seconds

    function checkUpcomingEvents() {
        var now = new Date();
        var upcomingEvents = [];

        events.forEach(event => {
            var start = new Date(event.start);
            if (start > now && start - now <= 30 * 60 * 1000) { // Check if event is within the next 5 minutes
                upcomingEvents.push(event);
            }
        });

        if (upcomingEvents.length > 0) {
            let notificationText = "Upcoming Events:\n";
            upcomingEvents.forEach(event => {
                notificationText += `- ${event.title} at ${new Date(event.start).toLocaleString()}\n`;
            });
            alert(notificationText); // Display alert notification (you can replace this with a custom modal or toast)
        }
    }

    // Other existing code remains unchanged
    $('#schedule-form').on('reset', function() {
        $(this).find('input:hidden').val('')
        $(this).find('input:visible').first().focus()
    })

    $('#edit').click(function() {
        var id = $(this).attr('data-id')
        if (!!scheds[id]) {
            var _form = $('#schedule-form')
            _form.find('[name="id"]').val(id)
            _form.find('[name="title"]').val(scheds[id].title)
            _form.find('[name="description"]').val(scheds[id].description)
            _form.find('[name="start_datetime"]').val(String(scheds[id].start_datetime).replace(" ", "T"))
            _form.find('[name="end_datetime"]').val(String(scheds[id].end_datetime).replace(" ", "T"))
            $('#event-details-modal').modal('hide')
            _form.find('[name="title"]').focus()
        } else {
            alert("Event is undefined");
        }
    })

    $('#delete').click(function() {
        var id = $(this).attr('data-id')
        if (!!scheds[id]) {
            var _conf = confirm("Are you sure to delete this scheduled event?");
            if (_conf === true) {
                location.href = "delete_schedule.php?id=" + id;
            }
        } else {
            alert("Event is undefined");
        }
    })
});
