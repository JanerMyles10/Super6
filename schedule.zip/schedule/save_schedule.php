<?php
// Start the session to get the logged-in user
session_start();

// Include the database connection file
require_once('db-connect.php');

// Check if the user is logged in
$user_email = $_SESSION['email'] ?? null;

if (!$user_email) {
    echo "<script> alert('You need to be logged in first.'); location.replace('login.html'); </script>";
    exit;
}

// Get POST data
extract($_POST);
$allday = isset($allday);

// Check if the form is to update or insert a new schedule
if (empty($id)) {
    // Insert a new schedule with the logged-in user's email
    $sql = "INSERT INTO `schedule_list` (`title`, `description`, `start_datetime`, `end_datetime`, `user_email`) 
            VALUES ('$title', '$description', '$start_datetime', '$end_datetime', '$user_email')";
} else {
    // Update the existing schedule only if the logged-in user owns it
    $sql = "UPDATE `schedule_list` 
            SET `title` = '$title', `description` = '$description', `start_datetime` = '$start_datetime', `end_datetime` = '$end_datetime' 
            WHERE `id` = '$id' AND `user_email` = '$user_email'"; 
}

$save = $conn->query($sql);

// Check if the operation was successful
if ($save) {
    echo "<script> alert('Schedule Successfully Saved.'); location.replace('./') </script>";
} else {
    echo "<pre>";
    echo "An Error occurred.<br>";
    echo "Error: " . $conn->error . "<br>";
    echo "SQL: " . $sql . "<br>";
    echo "</pre>";
}

// Close the connection
$conn->close();
?>
