<?php
include 'db-connect.php';

// Fetch data from users table
$user_sql = "SELECT * FROM users";
$user_result = $conn->query($user_sql);

// Fetch data from schedule_list table
$schedule_sql = "SELECT * FROM schedule_list";
$schedule_result = $conn->query($schedule_sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
</head>
<body>
    <h1>Admin Dashboard</h1>
    
    <!-- Users Table -->
    <h2>Users</h2>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Email</th>
            <th>Actions</th>
        </tr>
        <?php while($row = $user_result->fetch_assoc()): ?>
        <tr>
            <td><?php echo isset($row['id']) ? $row['id'] : ''; ?></td>
            <td><?php echo isset($row['email']) ? $row['email'] : ''; ?></td>
            <td>
                <a href="edit.php?id=<?php echo $row['id']; ?>">Edit</a> |
                <a href="delete_adminc.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure?')">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>

    <!-- Schedule List Table -->
    <h2>Schedule List</h2>
    <table border="1">
        <tr>
            <th>Schedule ID</th>
            <th>Title</th>
            <th>Start Time</th>
            <th>End Time</th>
            <th>User Email</th>
            <th>Actions</th>
        </tr>
        <?php while($row = $schedule_result->fetch_assoc()): ?>
        <tr>
            <td><?php echo isset($row['id']) ? $row['id'] : ''; ?></td>
            <td><?php echo isset($row['title']) ? $row['title'] : ''; ?></td>
            <td><?php echo isset($row['start_time']) ? $row['start_time'] : ''; ?></td>
            <td><?php echo isset($row['end_time']) ? $row['end_time'] : ''; ?></td>
            <td><?php echo isset($row['user_email']) ? $row['user_email'] : ''; ?></td>
            <td>
                <a href="edit_schedule.php?id=<?php echo $row['id']; ?>">Edit</a> |
                <a href="delete_schedule.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure?')">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>